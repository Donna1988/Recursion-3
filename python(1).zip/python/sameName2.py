
def chicken():
    global eggs
    eggs = "turkey eggs"

eggs = "global"
chicken()
print(eggs)





