

#catName1 = 'Zophie'
#catName2 = 'Pooka'
#catName3 = 'Simon'
#catName4 = 'Sara'
#catName5 = 'Jasmine'
#catName6 = 'Rally'

print("Enter the name of cat 1:")
catName1 = input()
print("Enter the name of cat 2:")
catName2 = input()
print("Enter the name of cat 3:")
catName3 = input()
print("Enter the name of cat 4:")
catName4 = input()
print("Enter the name of cat 5:")
catName5 = input()
print("Enter the name of cat 6:")
catName6 = input()

print("The cat names are: ")
print(catName1 + " "+ catName2 + " "+ catName3 + " "+ catName4 + " "+ catName5 + " "+ catName6)



