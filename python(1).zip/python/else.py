 # else statement example

print('who are you?')
name = input()
if name == 'Alice':
    print('Hi, Alice.')
else:
    print('Hello, Stranger.')
        
    
