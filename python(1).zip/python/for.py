# example for loop statement

print('My name is')
for i in range(5):
    print('Vincent Five Times (' + str(i) + ')')
    
