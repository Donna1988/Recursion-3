# example while loop

count = 0
while count < 5:
    print('Hello, World.')
    count = count + 1
    
