
print('''Dear Alice,

Eve's cat has been arrested for catnapping, cat burglary, and extortion.

Sincerely,
Bob''')



"""This is a multiline comment
to help explain what the greet()
function does."""
def greet():
    print("Hello there!")


