# example for loop statement using while

print('My name is')
i = 0
while i < 5:
    print('Vincent Five Times (' + str(i) + ')')
    i = i + 1
    
