
def hello(name):
    print("Hello "+ name)

hello("Vincent")
hello("John")
