

While True:
    print('Enter your age:')
    age = input()
    if age.isdecimal():
        break
    print('Please a enter a number for your age.')

