
def divide(divideBy):
    return 42 / divideBy

print(divide(2))
print(divide(12))
print(divide(0))
print(divide(3))


