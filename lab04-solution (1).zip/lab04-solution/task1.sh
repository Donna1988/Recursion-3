#!/bin/bash

# output the default values
echo "The initial value of para is: $para"
echo "The initial value of para2 is: $para2"
echo;echo

# Attempting to assign new values using parameter substitution 1 methods
para=${para-newValueforPara}
para2=${para2:-newValueforPara2} # Here : has to be used since the variable is declared

# output the new values
echo "New value for para is: $para"
echo "New value for para2 is: $para2"


