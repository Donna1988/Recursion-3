#!/bin/bash

# variable to control message
msg=0

# function to implement the counting of inputted word or sentence
str_manipulate(){

	# assign shell variable containing user input to a local variable "wo"
	wo=$*
	echo "The number of characters in your input is ${#wo}"
}


# begin and infinite loop
while [ true ]
do
	if [ $msg -ge 1 ]
	then
		echo "Enter another word or sentence (q to exit)"
	else
		echo "Enter a word or sentence (q to exit)"
	fi
	read word
	
	# check for command to exit
	if [ "$word" == "q" ]
	then
		break
	
	fi

# invoke the function with a single parameter
str_manipulate $word

# increment the message control value
msg=$(($msg+1))
echo

done
echo
echo "Bye! Was nice playing with you"

