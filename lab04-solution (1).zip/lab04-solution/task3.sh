#!/bin/bash

# check the number of argument the script is called with
if [ $# -ne 2 ]
then
	echo "USAGE $0 number1 number2"
	exit 1
fi

# function to implement the calculations
calc (){
	# assigning the shell variable value to normal variables
	num1=$1
	num2=$2
	
	# check for odd number
	if [ $(($num1%2)) -eq 1 ]
	then
		echo "$num1 + $num2 = $(($num1 + $num2))"
	else
		echo "$num1 * $num2 = $(($num1 * $num2))"
	fi
}

# invoke the function with two integer parameters
calc $1 $2
echo "Finished calculations."
