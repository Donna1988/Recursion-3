#!/bin/bash

# Output the original environment variables
echo "Initial Value of USER is $USER"
echo "Initial Value of LOGNAME is $LOGNAME"
echo "Initial Value of HOME is $HOME"
echo "Initial Value of SHELL is $SHELL" 
echo;echo

# Using parameter substitution 3 method to overwrite
user=${USER+newUserName}
logn=${LOGNAME+newLogName}
home=${HOME+newHomeValue}
shell=${SHELL+newShellValue}

# Using parameter substitution 2 method to assign default value
mycom=${MYCOM=NewCommandValue}

# Output the new values
echo "New value of USER is $user"
echo "New value of LOGNAME is $logn"
echo "New value of HOME is $home"
echo "New value of SHELL is $shell"
echo "Value assign to MYCOM is $mycom"
