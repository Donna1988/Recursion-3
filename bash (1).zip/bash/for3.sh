#!/bin/bash
for x 
  do
  echo "The value of variable x is: $x"
  sleep 1
done
