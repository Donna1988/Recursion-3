#!/bin/bash

# Define your function here
Hello () {
   echo "Hello $1 $2 Welcome to the World"
}

# Invoke your function
Hello Vincent Emeakaroha
