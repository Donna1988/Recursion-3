#!/bin/bash

echo -n "file name "; read filename

remove=$(rm -i $filename)

echo $remove

#$remove $filename

