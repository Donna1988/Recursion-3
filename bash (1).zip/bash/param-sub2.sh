#!/bin/bash

username=
echo "username has been declared, but is set to null."
echo "username = ${username=`whoami`}"

echo

echo username1 has not been declared.
echo "username1 = ${username1=`whoami`}"

username2=
echo "username2 has been declared, but is set to null."
echo "username2 = ${username2:=`whoami`}"

username3=bill
echo "username3 has been assigned the value bill."
echo "username3 = ${username3=`whoami`}"
echo "Parameter substitution has no effect on set variable"
