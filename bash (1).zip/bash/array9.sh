#!/bin/bash
filecontent=( `cat "myfile.txt" `)

for t in "${filecontent[@]}"
do
echo $t
done
echo "Finished reading file content!"
