#!/bin/bash
path=`pwd`
for filename in $path/test/* 	# Traverse all files in directory. 
do
	fname=`basename $filename`	#Extract the file names from the path 
	dname=`dirname $filename`	#Extract the directory path
  	lowCaseName=`echo $fname | tr A-Z a-z` 
  	if [ "$fname" != "$lowCaseName" ] # Rename only files not already lowercase. 
  	then 
		upper=`echo "$dname/$fname"`
		lower=`echo "$dname/$lowCaseName"`
    		mv $upper $lower	# Rename file 
  	fi 
done 
exit 0 

