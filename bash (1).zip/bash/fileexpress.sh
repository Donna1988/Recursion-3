#!/bin/bash
	if [ -e /etc/passwd ];
	then
		echo “Great it exist”
	else
		echo “This file does not exist.”
		exit 1
	fi

