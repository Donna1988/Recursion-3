#!/bin/bash 
echo –n "Enter a number: "; read n
let sum=0; let i=1	
while [ $i -le $n ]
do
  let sum=$sum+$i
	((i=$i+1))
done
echo "The sum of the first $n numbers is: $sum"

