#!/bin/bash
: ${HOSTNAME?} ${USER?} ${HOME?} 
echo
echo "Name of the machine is $HOSTNAME."
echo "You are $USER."

#myName=Vincent
: ${myName?"myName variable not set"}

echo "Your home directory is $HOME."

