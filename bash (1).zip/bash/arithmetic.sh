#!/bin/bash
echo -n "Enter the first number: "; read x
echo -n "Enter the second number: "; read y
echo "here"
add=$(($x + $y)) 
sub=$(($x - $y)) 
mul=$(($x * $y)) 
div=$(($x / $y)) 
mod=$(($x % $y))
# print out the answers:
echo "Sum: $add"
echo "Difference: $sub"
echo "Product: $mul"
echo "Quotient: $div"
echo "Remainder: $mod"

