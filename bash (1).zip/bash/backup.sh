#!/bin/bash

BCKUP=/home/$USER/backup-$(date +%d-%m-%y).tar.gz
tar -czf $BCKUP $HOME

