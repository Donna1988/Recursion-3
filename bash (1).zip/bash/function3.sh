#!/bin/bash

# Define your function here
Hello () {
   echo "Hello $1 $2 Welcome to the World"
   return 20
}

# Invoke your function
Hello Vincent Emeakaroha

# Capture value returnd by last command
ret=$?

echo "Return value is $ret"
