#!/bin/bash

# Define your function here
Hello () {
   echo "Hello Welcome to the World"
}

# Invoke your function
Hello
