#!/bin/bash

echo "$#; $0; $1; $2; $*; $@"

